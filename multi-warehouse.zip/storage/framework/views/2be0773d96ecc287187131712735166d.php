

<?php $__env->startSection('title', 'Daftar Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="mb-1">Daftar Transaksi</h4>
        <p class="text-muted mb-0">Dokumen transaksi stok masuk dan keluar</p>
    </div>
    <?php if(auth()->user()->canCreateTransaction()): ?>
    <div class="btn-group">
        <a href="<?php echo e(route('stock-headers.create-in')); ?>" class="btn btn-success">
            <i class="bi bi-plus-lg me-1"></i> Stok Masuk
        </a>
        <a href="<?php echo e(route('stock-headers.create-out')); ?>" class="btn btn-danger">
            <i class="bi bi-dash-lg me-1"></i> Stok Keluar
        </a>
    </div>
    <?php endif; ?>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form action="<?php echo e(route('stock-headers.index')); ?>" method="GET" class="row g-3">
            <div class="col-md-3">
                <label class="form-label small">Gudang</label>
                <?php if(auth()->user()->isAdmin() || auth()->user()->isOwner()): ?>
                    <select name="warehouse_id" class="form-select">
                        <option value="">Semua Gudang</option>
                        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($w->id); ?>" <?php echo e(request('warehouse_id') == $w->id ? 'selected' : ''); ?>>
                                <?php echo e($w->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <input type="text" class="form-control bg-light" value="<?php echo e(auth()->user()->warehouse->name ?? '-'); ?>" readonly>
                    <input type="hidden" name="warehouse_id" value="<?php echo e(auth()->user()->warehouse_id); ?>">
                <?php endif; ?>
            </div>
            <div class="col-md-3">
                <label class="form-label small">Jenis Transaksi</label>
                <select name="type" class="form-select">
                    <option value="">Semua</option>
                    <option value="in" <?php echo e(request('type') == 'in' ? 'selected' : ''); ?>>Stok Masuk</option>
                    <option value="out" <?php echo e(request('type') == 'out' ? 'selected' : ''); ?>>Stok Keluar</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small">Dari Tanggal</label>
                <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small">&nbsp;</label>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-funnel me-1"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Transactions Table -->
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>No. Dokumen</th>
                        <th>Gudang</th>
                        <th>Tanggal</th>
                        <th>Jenis</th>
                        <th class="text-center">Jumlah Item</th>
                        <th class="text-center">Total Qty</th>
                        <th>Petugas</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('stock-headers.show', $header)); ?>" class="fw-semibold text-decoration-none">
                                <?php echo e($header->document_number); ?>

                            </a>
                        </td>
                        <td>
                            <span class="badge bg-light text-dark border">
                                <i class="bi bi-building me-1"></i><?php echo e($header->warehouse->name ?? '-'); ?>

                            </span>
                        </td>
                        <td><?php echo e($header->transaction_date->format('d/m/Y H:i')); ?></td>
                        <td>
                            <span class="badge <?php echo e($header->type_badge_class); ?>">
                                <?php echo e($header->type_label); ?>

                            </span>
                        </td>
                        <td class="text-center"><?php echo e($header->total_items); ?></td>
                        <td class="text-center fw-semibold <?php echo e($header->type === 'in' ? 'text-success' : 'text-danger'); ?>">
                            <?php echo e($header->type === 'in' ? '+' : '-'); ?><?php echo e($header->total_quantity); ?>

                        </td>
                        <td><?php echo e($header->user->name); ?></td>
                        <td>
                            <?php if($header->isReceiptLocked()): ?>
                            <span class="badge bg-info"><i class="bi bi-lock me-1"></i>Dikunci</span>
                            <?php elseif($header->hasCompleteSignatures()): ?>
                            <span class="badge bg-success"><i class="bi bi-check me-1"></i>Ditandatangani</span>
                            <?php else: ?>
                            <span class="badge bg-secondary">Belum TTD</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-light border dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('stock-headers.show', $header)); ?>">
                                            <i class="bi bi-eye text-info me-2"></i> Lihat Detail
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('stock-headers.receipt', $header)); ?>">
                                            <i class="bi bi-file-earmark-text text-primary me-2"></i> Tanda Terima
                                        </a>
                                    </li>
                                    <?php if($header->hasCompleteSignatures()): ?>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('stock-headers.pdf', $header)); ?>" target="_blank">
                                            <i class="bi bi-file-pdf text-danger me-2"></i> Download PDF
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->isAdmin() && !$header->isReceiptLocked()): ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <form action="<?php echo e(route('stock-headers.destroy', $header)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus transaksi ini? Stok akan dikembalikan.')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="dropdown-item text-danger">
                                                <i class="bi bi-trash me-2"></i> Hapus
                                            </button>
                                        </form>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-5">
                            <i class="bi bi-inbox fs-1 text-muted"></i>
                            <p class="text-muted mt-2 mb-0">Tidak ada transaksi ditemukan</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($headers->hasPages()): ?>
    <div class="card-footer">
        <?php echo e($headers->withQueryString()->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/stock-headers/index.blade.php ENDPATH**/ ?>