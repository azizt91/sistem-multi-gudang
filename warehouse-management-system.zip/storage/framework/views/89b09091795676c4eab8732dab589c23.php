<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Stok - <?php echo e(now()->format('d F Y')); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.5;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        .header h1 {
            margin: 0;
            font-size: 18px;
        }
        .header p {
            margin: 5px 0 0;
            color: #666;
        }
        .summary {
            display: table;
            width: 100%;
            margin-bottom: 20px;
        }
        .summary-item {
            display: table-cell;
            width: 33.33%;
            text-align: center;
            padding: 10px;
            border: 1px solid #ddd;
        }
        .summary-value {
            font-size: 20px;
            font-weight: bold;
        }
        .summary-label {
            font-size: 11px;
            color: #666;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 6px;
            text-align: left;
            font-size: 10px;
        }
        th {
            background-color: #4F46E5;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .text-success { color: #10B981; }
        .text-danger { color: #EF4444; }
        .badge {
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 9px;
            display: inline-block;
        }
        .badge-success { background: #10B981; color: white; }
        .badge-danger { background: #EF4444; color: white; }
        .footer {
            margin-top: 20px;
            text-align: center;
            font-size: 10px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="header">
        <?php
            $profile = \App\Models\CompanyProfile::first();
        ?>
        <?php if($profile && $profile->logo_path): ?>
            <img src="<?php echo e(public_path('storage/' . $profile->logo_path)); ?>" style="height: 40px; margin-bottom: 5px;">
        <?php endif; ?>
        <h1 style="font-size: 16px; margin-top: 5px;"><?php echo e($profile->company_name ?? 'WMS'); ?></h1>
        <div style="margin-bottom: 10px; font-size: 10px; color: #666;"><?php echo e($profile->address ?? ''); ?></div>

        <h2 style="font-size: 14px; margin-top: 15px; border-top: 1px solid #333; padding-top: 10px;">LAPORAN STOK BARANG</h2>
        <p>Tanggal Cetak: <?php echo e(now()->format('d F Y H:i')); ?></p>
        <p>
            Gudang: <?php echo e($warehouse ? $warehouse->name : 'Semua Gudang'); ?> |
            Kategori: <?php echo e($category ? $category->name : 'Semua Kategori'); ?>

        </p>
    </div>

    <table>
        <thead>
            <tr>
                <th width="15%">Kota</th>
                <th width="15%">Kode Barang</th>
                <th>Nama Barang</th>
                <th width="15%">Kategori</th>
                <th class="text-center" width="8%">Satuan</th>
                <th class="text-center" width="10%">Stok</th>
                <th class="text-center" width="10%">Min. Stok</th>
                <th class="text-center" width="10%">Status</th>
                <th width="10%">Lokasi Rak</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($row->city); ?></td>
                <td><?php echo e($row->item_code); ?></td>
                <td><?php echo e($row->item_name); ?></td>
                <td><?php echo e($row->category_name); ?></td>
                <td class="text-center"><?php echo e($row->unit_name); ?></td>
                <td class="text-center fw-bold">
                    <?php echo e($row->stock); ?>

                </td>
                <td class="text-center"><?php echo e($row->minimum_stock); ?></td>
                <td class="text-center">
                    <?php if($row->status === 'Low Stock'): ?>
                        <span class="badge badge-danger">Menipis</span>
                    <?php else: ?>
                        <span class="badge badge-success">Normal</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($row->rack_location ?? '-'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="9" class="text-center">Tidak ada data stok barang</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="footer">
        Dicetak oleh: <?php echo e(auth()->user()->name); ?> | Warehouse Management System
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/reports/pdf/stock.blade.php ENDPATH**/ ?>