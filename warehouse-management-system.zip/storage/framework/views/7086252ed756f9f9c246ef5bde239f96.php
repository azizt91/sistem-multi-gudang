<!-- Summary Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="stats-card primary">
            <div class="stats-value"><?php echo e(number_format($summary['total_items'])); ?></div>
            <div class="stats-label">Total Jenis Barang</div>
            <i class="bi bi-box-seam stats-icon"></i>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stats-card info">
            <div class="stats-value"><?php echo e(number_format($summary['total_stock'])); ?></div>
            <div class="stats-label">Total Stok</div>
            <i class="bi bi-boxes stats-icon"></i>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stats-card warning">
            <div class="stats-value"><?php echo e(number_format($summary['low_stock_count'])); ?></div>
            <div class="stats-label">Stok Menipis</div>
            <i class="bi bi-exclamation-triangle stats-icon"></i>
        </div>
    </div>
</div>

<!-- Stock Table -->
<div class="card">
    <div class="card-header">
        <i class="bi bi-list-ul me-2"></i>Daftar Stok Barang
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th width="150" class="bg-light">Gudang</th> <!-- Added Warehouse Column -->
                        <th>Kode</th>
                        <th>Nama Barang</th>
                        <th>Kategori</th>
                        <th class="text-center">Stok</th>
                        <th class="text-center">Min</th>
                        <th>Satuan</th>
                        <th>Status</th>
                        <th>Lokasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="fw-semibold"><?php echo e($item->warehouse_name); ?></td> <!-- Show Warehouse Name -->
                        <td><code><?php echo e($item->item_code); ?></code></td>
                        <td><?php echo e($item->item_name); ?></td>
                        <td><?php echo e($item->category_name); ?></td>
                        <td class="text-center fw-bold <?php echo e($item->status == 'Low Stock' ? 'text-danger' : 'text-success'); ?>">
                            <?php echo e($item->stock); ?>

                        </td>
                        <td class="text-center"><?php echo e($item->minimum_stock); ?></td>
                        <td><?php echo e($item->unit_name); ?></td>
                        <td>
                            <?php if($item->status == 'Low Stock'): ?>
                            <span class="badge bg-danger">Stok Menipis</span>
                            <?php else: ?>
                            <span class="badge bg-success">Normal</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item->rack_location ?? '-'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="text-center py-5">
                            <i class="bi bi-inbox fs-1 text-muted"></i>
                            <p class="text-muted mt-2 mb-0">Tidak ada barang</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/reports/partials/stock_content.blade.php ENDPATH**/ ?>