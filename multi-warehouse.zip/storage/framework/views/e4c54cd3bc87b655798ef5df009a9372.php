

<?php $__env->startSection('title', 'Stok Masuk'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header bg-success text-white">
                <i class="bi bi-box-arrow-in-down me-2"></i>Input Stok Masuk
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('transactions.stock-in.store')); ?>" method="POST" id="stockForm">
                    <?php echo csrf_field(); ?>

                    <!-- Barcode Scanner Section -->
                    <div class="mb-4 p-3 rounded border" style="background: var(--table-hover);">
                        <h6 class="fw-semibold mb-3">
                            <i class="bi bi-upc-scan me-2"></i>Scan Barcode (Opsional)
                        </h6>
                        <div class="input-group">
                            <input type="text" class="form-control" id="barcodeInput" placeholder="Scan atau ketik kode barang...">
                            <button type="button" class="btn btn-primary" id="searchBtn">
                                <i class="bi bi-search"></i> Cari
                            </button>
                        </div>
                        <div id="scanResult" class="mt-2"></div>
                    </div>

                    <div class="row g-3">
                        <div class="col-12">
                            <label for="item_id" class="form-label">Pilih Barang <span class="text-danger">*</span></label>
                            <select class="form-select <?php $__errorArgs = ['item_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="item_id" name="item_id" required>
                                <option value="">-- Pilih Barang --</option>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" 
                                    data-stock="<?php echo e($item->stock); ?>" 
                                    data-unit="<?php echo e($item->unit->abbreviation); ?>"
                                    <?php echo e(old('item_id', request('item_id')) == $item->id ? 'selected' : ''); ?>>
                                    <?php echo e($item->code); ?> - <?php echo e($item->name); ?> (Stok: <?php echo e($item->stock); ?> <?php echo e($item->unit->abbreviation); ?>)
                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['item_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Item Preview -->
                        <div class="col-12" id="itemPreview" style="display: none;">
                            <div class="alert alert-info mb-0">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong id="previewName"></strong>
                                        <br>
                                        <small>Stok saat ini: <span id="previewStock" class="fw-bold"></span></small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <label for="quantity" class="form-label">Jumlah Masuk <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input type="number" class="form-control <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="quantity" name="quantity" value="<?php echo e(old('quantity', 1)); ?>" min="1" required>
                                <span class="input-group-text" id="unitLabel">-</span>
                            </div>
                            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-6">
                            <label for="notes" class="form-label">Catatan</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="notes" name="notes" value="<?php echo e(old('notes')); ?>" placeholder="Contoh: Pembelian dari supplier X">
                            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="d-flex justify-content-between">
                        <a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-secondary">
                            <i class="bi bi-arrow-left me-1"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-lg me-1"></i> Simpan Stok Masuk
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const itemSelect = document.getElementById('item_id');
    const itemPreview = document.getElementById('itemPreview');
    const previewName = document.getElementById('previewName');
    const previewStock = document.getElementById('previewStock');
    const unitLabel = document.getElementById('unitLabel');
    const barcodeInput = document.getElementById('barcodeInput');
    const searchBtn = document.getElementById('searchBtn');
    const scanResult = document.getElementById('scanResult');

    // Update preview when item selected
    itemSelect.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        if (this.value) {
            previewName.textContent = selectedOption.text.split(' (Stok:')[0];
            previewStock.textContent = selectedOption.dataset.stock + ' ' + selectedOption.dataset.unit;
            unitLabel.textContent = selectedOption.dataset.unit;
            itemPreview.style.display = 'block';
        } else {
            itemPreview.style.display = 'none';
            unitLabel.textContent = '-';
        }
    });

    // Trigger on page load if item pre-selected
    if (itemSelect.value) {
        itemSelect.dispatchEvent(new Event('change'));
    }

    // Barcode search
    function searchBarcode() {
        const code = barcodeInput.value.trim();
        if (!code) return;

        scanResult.innerHTML = '<span class="text-muted"><i class="bi bi-hourglass-split"></i> Mencari...</span>';

        fetch('<?php echo e(route("items.find-by-code")); ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': window.csrfToken
            },
            body: JSON.stringify({ code: code })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                scanResult.innerHTML = `<div class="alert alert-success mb-0 py-2">
                    <i class="bi bi-check-circle me-1"></i> Ditemukan: <strong>${data.item.name}</strong>
                </div>`;
                // Select the item
                for (let option of itemSelect.options) {
                    if (option.value == data.item.id) {
                        option.selected = true;
                        itemSelect.dispatchEvent(new Event('change'));
                        break;
                    }
                }
            } else {
                scanResult.innerHTML = `<div class="alert alert-danger mb-0 py-2">
                    <i class="bi bi-x-circle me-1"></i> ${data.message}
                </div>`;
            }
        })
        .catch(error => {
            scanResult.innerHTML = `<div class="alert alert-danger mb-0 py-2">
                <i class="bi bi-x-circle me-1"></i> Terjadi kesalahan
            </div>`;
        });
    }

    searchBtn.addEventListener('click', searchBarcode);
    barcodeInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            searchBarcode();
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/transactions/stock-in.blade.php ENDPATH**/ ?>