

<?php $__env->startSection('title', 'Detail Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1"><?php echo e($stockHeader->document_number); ?></h4>
                <p class="text-muted mb-0"><?php echo e($stockHeader->type_label); ?> - <?php echo e($stockHeader->transaction_date->format('d F Y, H:i')); ?></p>
            </div>
            <div>
                <a href="<?php echo e(route('stock-headers.index')); ?>" class="btn btn-secondary me-2">
                    <i class="bi bi-arrow-left me-1"></i> Kembali
                </a>
                <a href="<?php echo e(route('stock-headers.receipt', $stockHeader)); ?>" class="btn btn-primary">
                    <i class="bi bi-file-earmark-text me-1"></i> Tanda Terima
                </a>
            </div>
        </div>

        <!-- Transaction Info -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>
                    <i class="bi <?php echo e($stockHeader->type === 'in' ? 'bi-box-arrow-in-down text-success' : 'bi-box-arrow-up text-danger'); ?> me-2"></i>
                    Informasi Transaksi
                </span>
                <span class="badge <?php echo e($stockHeader->type_badge_class); ?>"><?php echo e($stockHeader->type_label); ?></span>
            </div>
            <div class="card-body">
                <div class="row g-4">
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless mb-0">
                            <tr>
                                <td width="140"><strong>No. Dokumen</strong></td>
                                <td><?php echo e($stockHeader->document_number); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Tanggal</strong></td>
                                <td><?php echo e($stockHeader->transaction_date->format('d F Y, H:i')); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Petugas</strong></td>
                                <td><?php echo e($stockHeader->user->name); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Gudang</strong></td>
                                <td><?php echo e($stockHeader->warehouse->name ?? '-'); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless mb-0">
                            <tr>
                                <td width="120"><strong>Total Item</strong></td>
                                <td><?php echo e($stockHeader->total_items); ?> barang</td>
                            </tr>
                            <tr>
                                <td><strong>Total Qty</strong></td>
                                <td class="fw-bold <?php echo e($stockHeader->type === 'in' ? 'text-success' : 'text-danger'); ?>">
                                    <?php echo e($stockHeader->type === 'in' ? '+' : '-'); ?><?php echo e($stockHeader->total_quantity); ?>

                                </td>
                            </tr>
                            <tr>
                                <td><strong>Status</strong></td>
                                <td>
                                    <?php if($stockHeader->isReceiptLocked()): ?>
                                    <span class="badge bg-info"><i class="bi bi-lock me-1"></i>Dikunci</span>
                                    <?php elseif($stockHeader->hasCompleteSignatures()): ?>
                                    <span class="badge bg-success"><i class="bi bi-check me-1"></i>Ditandatangani</span>
                                    <?php else: ?>
                                    <span class="badge bg-secondary">Belum TTD</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <?php if($stockHeader->notes): ?>
                <hr>
                <div>
                    <strong>Catatan:</strong>
                    <p class="mb-0 text-muted"><?php echo e($stockHeader->notes); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Items List -->
        <div class="card mb-4">
            <div class="card-header">
                <i class="bi bi-box-seam me-2"></i>Daftar Barang (<?php echo e($stockHeader->total_items); ?> item)
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th width="50">#</th>
                                <th>Kode</th>
                                <th>Nama Barang</th>
                                <th class="text-center">Qty</th>
                                <th>Satuan</th>
                                <th>Stok Sebelum</th>
                                <th>Stok Sesudah</th>
                                <th>Catatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $stockHeader->transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><code><?php echo e($transaction->item->code); ?></code></td>
                                <td><?php echo e($transaction->item->name); ?></td>
                                <td class="text-center fw-bold <?php echo e($stockHeader->type === 'in' ? 'text-success' : 'text-danger'); ?>">
                                    <?php echo e($stockHeader->type === 'in' ? '+' : '-'); ?><?php echo e($transaction->quantity); ?>

                                </td>
                                <td><?php echo e($transaction->item->unit->abbreviation); ?></td>
                                <td><?php echo e($transaction->stock_before); ?></td>
                                <td><?php echo e($transaction->stock_after); ?></td>
                                <td><?php echo e($transaction->notes ?? '-'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot class="table-light">
                            <tr>
                                <th colspan="3" class="text-end">Total:</th>
                                <th class="text-center <?php echo e($stockHeader->type === 'in' ? 'text-success' : 'text-danger'); ?>">
                                    <?php echo e($stockHeader->type === 'in' ? '+' : '-'); ?><?php echo e($stockHeader->total_quantity); ?>

                                </th>
                                <th colspan="4"></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        <!-- Receipt Status -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-file-earmark-text me-2"></i>Status Tanda Terima
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="d-flex align-items-center mb-3">
                            <?php if($stockHeader->sender_signature): ?>
                            <i class="bi bi-check-circle-fill text-success fs-4 me-2"></i>
                            <?php else: ?>
                            <i class="bi bi-circle text-muted fs-4 me-2"></i>
                            <?php endif; ?>
                            <div>
                                <strong><?php echo e($stockHeader->type === 'in' ? 'Pengirim' : 'Penerima'); ?></strong>
                                <br>
                                <small class="text-muted"><?php echo e($stockHeader->sender_name ?: 'Belum diisi'); ?></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex align-items-center mb-3">
                            <?php if($stockHeader->receiver_signature): ?>
                            <i class="bi bi-check-circle-fill text-success fs-4 me-2"></i>
                            <?php else: ?>
                            <i class="bi bi-circle text-muted fs-4 me-2"></i>
                            <?php endif; ?>
                            <div>
                                <strong><?php echo e($stockHeader->type === 'in' ? 'Penerima (Gudang)' : 'Pengirim (Gudang)'); ?></strong>
                                <br>
                                <small class="text-muted"><?php echo e($stockHeader->receiver_name ?: 'Belum diisi'); ?></small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex gap-2">
                    <?php if(!$stockHeader->isReceiptLocked()): ?>
                    <a href="<?php echo e(route('stock-headers.receipt', $stockHeader)); ?>" class="btn btn-outline-primary">
                        <i class="bi bi-pen me-1"></i> Input Tanda Tangan
                    </a>
                    <?php endif; ?>

                    <?php if($stockHeader->hasCompleteSignatures()): ?>
                    <a href="<?php echo e(route('stock-headers.pdf', $stockHeader)); ?>" class="btn btn-danger" target="_blank">
                        <i class="bi bi-file-pdf me-1"></i> Download PDF
                    </a>
                    <?php endif; ?>
                </div>

                <?php if($stockHeader->isReceiptLocked()): ?>
                <div class="alert alert-info mb-0 mt-3">
                    <i class="bi bi-lock me-2"></i>
                    Tanda terima sudah dikunci pada <?php echo e($stockHeader->updated_at->format('d/m/Y H:i')); ?>.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/stock-headers/show.blade.php ENDPATH**/ ?>