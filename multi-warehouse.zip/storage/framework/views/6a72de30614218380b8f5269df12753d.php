

<?php $__env->startSection('title', 'Transfer Stok'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="mb-1">Transfer Stok Antar Gudang</h4>
        <p class="text-muted mb-0">Kelola perpindahan stok antar gudang</p>
    </div>
    <?php if(!auth()->user()->isOwner()): ?>
    <a href="<?php echo e(route('stock-transfers.create')); ?>" class="btn btn-primary">
        <i class="bi bi-arrow-left-right me-1"></i> Transfer Baru
    </a>
    <?php endif; ?>
</div>

<div class="card mb-4">
    <div class="card-body">
        <form action="<?php echo e(route('stock-transfers.index')); ?>" method="GET" class="row g-3">
            <div class="col-md-4">
                <select name="warehouse_id" class="form-select">
                    <option value="">Semua Gudang</option>
                    <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($warehouse->id); ?>" <?php echo e(request('warehouse_id') == $warehouse->id ? 'selected' : ''); ?>>
                        <?php echo e($warehouse->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-filter me-1"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Nomor Transfer</th>
                        <th>Gudang Asal</th>
                        <th>Gudang Tujuan</th>
                        <th>Status</th>
                        <th>User</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="fw-semibold"><?php echo e($transfer->transfer_number); ?></td>
                        <td><?php echo e($transfer->sourceWarehouse->name); ?></td>
                        <td><?php echo e($transfer->destinationWarehouse->name); ?></td>
                        <td>
                            <span class="badge bg-success">Selesai</span>
                        </td>
                        <td><?php echo e($transfer->user->name); ?></td>
                        <td><?php echo e($transfer->created_at->format('d/m/Y H:i')); ?></td>
                        <td>
                            <a href="<?php echo e(route('stock-transfers.show', $transfer)); ?>" class="btn btn-sm btn-info text-white">
                                <i class="bi bi-eye"></i> Detail
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-5">
                            <i class="bi bi-arrow-left-right fs-1 text-muted"></i>
                            <p class="text-muted mt-2 mb-0">Belum ada data transfer stok</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($transfers->hasPages()): ?>
    <div class="card-footer">
        <?php echo e($transfers->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/stock-transfers/index.blade.php ENDPATH**/ ?>