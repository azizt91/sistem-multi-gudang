

<?php $__env->startSection('title', 'Daftar Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="mb-1">Daftar Transaksi</h4>
        <p class="text-muted mb-0">Dokumen transaksi stok masuk dan keluar</p>
    </div>
    <?php if(auth()->user()->canCreateTransaction()): ?>
    <div class="btn-group">
        <a href="<?php echo e(route('stock-headers.create-in')); ?>" class="btn btn-success">
            <i class="bi bi-plus-lg me-1"></i> Stok Masuk
        </a>
        <a href="<?php echo e(route('stock-headers.create-out')); ?>" class="btn btn-danger">
            <i class="bi bi-dash-lg me-1"></i> Stok Keluar
        </a>
    </div>
    <?php endif; ?>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form id="filterForm" class="row g-3">
            <div class="col-md-3">
                <label class="form-label small">Gudang</label>
                <?php if(auth()->user()->isAdmin() || auth()->user()->isOwner()): ?>
                    <select name="warehouse_id" class="form-select filter-input">
                        <option value="">Semua Gudang</option>
                        <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($w->id); ?>" <?php echo e(request('warehouse_id') == $w->id ? 'selected' : ''); ?>>
                                <?php echo e($w->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <input type="text" class="form-control bg-light" value="<?php echo e(auth()->user()->warehouse->name ?? '-'); ?>" readonly>
                    <input type="hidden" name="warehouse_id" value="<?php echo e(auth()->user()->warehouse_id); ?>">
                <?php endif; ?>
            </div>
            <div class="col-md-3">
                <label class="form-label small">Jenis Transaksi</label>
                <select name="type" class="form-select filter-input">
                    <option value="">Semua</option>
                    <option value="in" <?php echo e(request('type') == 'in' ? 'selected' : ''); ?>>Stok Masuk</option>
                    <option value="out" <?php echo e(request('type') == 'out' ? 'selected' : ''); ?>>Stok Keluar</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small">Dari Tanggal</label>
                <input type="date" name="start_date" class="form-control filter-input" value="<?php echo e(request('start_date')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small">Sampai Tanggal</label>
                <input type="date" name="end_date" class="form-control filter-input" value="<?php echo e(request('end_date')); ?>">
            </div>
        </form>
    </div>
</div>

<!-- Transactions Table -->
<div class="card">
    <div class="card-body p-0" id="table-container">
        <?php echo $__env->make('stock-headers.partials.table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const filterForm = document.getElementById('filterForm');
    const tableContainer = document.getElementById('table-container');
    const inputs = filterForm.querySelectorAll('.filter-input');

    function fetchTable(url) {
        // Show loading state if needed
        tableContainer.style.opacity = '0.5';
        
        // If no url provided, build from form
        if (!url) {
            const formData = new FormData(filterForm);
            const params = new URLSearchParams(formData);
            url = '<?php echo e(route("stock-headers.index")); ?>?' + params.toString();
        }

        // Update URL
        history.pushState(null, '', url);

        fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.text())
        .then(html => {
            tableContainer.innerHTML = html;
            tableContainer.style.opacity = '1';
            rebindPagination();
        })
        .catch(error => {
            console.error('Error:', error);
            tableContainer.style.opacity = '1';
        });
    }

    function rebindPagination() {
        const links = tableContainer.querySelectorAll('.pagination a');
        links.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                fetchTable(this.href);
            });
        });
    }

    // Attach listeners
    inputs.forEach(input => {
        input.addEventListener('change', () => fetchTable());
        // For date inputs, change event is good enough
    });

    // Initial binding
    rebindPagination();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/stock-headers/index.blade.php ENDPATH**/ ?>