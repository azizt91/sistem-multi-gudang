

<?php $__env->startSection('title', 'Riwayat Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="mb-1">Riwayat Transaksi</h4>
        <p class="text-muted mb-0">Lihat semua transaksi stok masuk dan keluar</p>
    </div>
    <?php if(auth()->user()->canCreateTransaction()): ?>
    <div class="btn-group">
        <a href="<?php echo e(route('transactions.stock-in')); ?>" class="btn btn-success">
            <i class="bi bi-plus-lg me-1"></i> Stok Masuk
        </a>
        <a href="<?php echo e(route('transactions.stock-out')); ?>" class="btn btn-danger">
            <i class="bi bi-dash-lg me-1"></i> Stok Keluar
        </a>
    </div>
    <?php endif; ?>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form action="<?php echo e(route('transactions.index')); ?>" method="GET" class="row g-3">
            <div class="col-md-3">
                <label class="form-label small">Jenis Transaksi</label>
                <select name="type" class="form-select">
                    <option value="">Semua</option>
                    <option value="in" <?php echo e(request('type') == 'in' ? 'selected' : ''); ?>>Stok Masuk</option>
                    <option value="out" <?php echo e(request('type') == 'out' ? 'selected' : ''); ?>>Stok Keluar</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small">Barang</label>
                <select name="item_id" class="form-select">
                    <option value="">Semua Barang</option>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>" <?php echo e(request('item_id') == $item->id ? 'selected' : ''); ?>>
                        <?php echo e($item->code); ?> - <?php echo e($item->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small">Dari Tanggal</label>
                <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small">Sampai Tanggal</label>
                <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small">&nbsp;</label>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-funnel me-1"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Transactions Table -->
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Kode</th>
                        <th>Barang</th>
                        <th>Jenis</th>
                        <th class="text-end">Qty</th>
                        <th>Stok Sebelum</th>
                        <th>Stok Sesudah</th>
                        <th>User</th>
                        <th>Catatan</th>
                        <?php if(auth()->user()->canDeleteTransaction()): ?>
                        <th>Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($transaction->transaction_date->format('d/m/Y H:i')); ?></td>
                        <td><code><?php echo e($transaction->item->code); ?></code></td>
                        <td><?php echo e(Str::limit($transaction->item->name, 25)); ?></td>
                        <td>
                            <span class="badge <?php echo e($transaction->type_badge_class); ?>">
                                <?php echo e($transaction->type_label); ?>

                            </span>
                        </td>
                        <td class="text-end fw-semibold <?php echo e($transaction->type === 'in' ? 'text-success' : 'text-danger'); ?>">
                            <?php echo e($transaction->type === 'in' ? '+' : '-'); ?><?php echo e($transaction->quantity); ?>

                        </td>
                        <td><?php echo e($transaction->stock_before); ?></td>
                        <td><?php echo e($transaction->stock_after); ?></td>
                        <td><?php echo e($transaction->user->name); ?></td>
                        <td><?php echo e(Str::limit($transaction->notes, 20) ?? '-'); ?></td>
                        <?php if(auth()->user()->canDeleteTransaction()): ?>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-light border dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <i class="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('transactions.show', $transaction)); ?>">
                                            <i class="bi bi-eye text-info me-2"></i> Lihat Detail
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('transactions.receipt', $transaction)); ?>">
                                            <i class="bi bi-file-earmark-text text-primary me-2"></i> Tanda Terima
                                        </a>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <form action="<?php echo e(route('transactions.destroy', $transaction)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus transaksi ini? Stok akan dikembalikan.')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="dropdown-item text-danger">
                                                <i class="bi bi-trash me-2"></i> Hapus
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="<?php echo e(auth()->user()->canDeleteTransaction() ? 10 : 9); ?>" class="text-center py-5">
                            <i class="bi bi-inbox fs-1 text-muted"></i>
                            <p class="text-muted mt-2 mb-0">Tidak ada transaksi ditemukan</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($transactions->hasPages()): ?>
    <div class="card-footer">
        <?php echo e($transactions->withQueryString()->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/transactions/index.blade.php ENDPATH**/ ?>