

<?php $__env->startSection('title', 'Transfer Stok'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="mb-1">Transfer Stok Antar Gudang</h4>
        <p class="text-muted mb-0">Kelola perpindahan stok antar gudang</p>
    </div>
    <?php if(!auth()->user()->isOwner()): ?>
    <a href="<?php echo e(route('stock-transfers.create')); ?>" class="btn btn-primary">
        <i class="bi bi-arrow-left-right me-1"></i> Transfer Baru
    </a>
    <?php endif; ?>
</div>

<?php if(auth()->user()->isAdmin() || auth()->user()->isOwner()): ?>
<div class="card mb-4">
    <div class="card-body">
        <form id="filterForm" class="row g-3">
            <div class="col-md-4">
                <select name="warehouse_id" class="form-select filter-input">
                    <option value="">Semua Gudang</option>
                    <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($warehouse->id); ?>" <?php echo e(request('warehouse_id') == $warehouse->id ? 'selected' : ''); ?>>
                        <?php echo e($warehouse->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-body p-0" id="table-container">
        <?php echo $__env->make('stock-transfers.partials.table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const filterForm = document.getElementById('filterForm');
    const tableContainer = document.getElementById('table-container');

    // If filter form doesn't exist (e.g. staff), no JS needed for filtering
    if (!filterForm) return;

    const inputs = filterForm.querySelectorAll('.filter-input');

    function fetchTable(url) {
        // Show loading state
        tableContainer.style.opacity = '0.5';
        
        // If no url provided, build from form
        if (!url) {
            const formData = new FormData(filterForm);
            const params = new URLSearchParams(formData);
            url = '<?php echo e(route("stock-transfers.index")); ?>?' + params.toString();
        }

        // Update URL
        history.pushState(null, '', url);

        fetch(url, {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.text())
        .then(html => {
            tableContainer.innerHTML = html;
            tableContainer.style.opacity = '1';
            rebindPagination();
        })
        .catch(error => {
            console.error('Error:', error);
            tableContainer.style.opacity = '1';
        });
    }

    function rebindPagination() {
        const links = tableContainer.querySelectorAll('.pagination a');
        links.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                fetchTable(this.href);
            });
        });
    }

    // Attach listeners
    inputs.forEach(input => {
        input.addEventListener('change', () => fetchTable());
    });

    // Initial binding for pagination
    rebindPagination();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/stock-transfers/index.blade.php ENDPATH**/ ?>