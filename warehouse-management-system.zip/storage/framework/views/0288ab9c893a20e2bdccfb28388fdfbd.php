

<?php $__env->startSection('title', 'Audit Logs'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="mb-1">Audit Logs</h4>
        <p class="text-muted mb-0">Riwayat aktivitas penting sistem</p>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <form action="<?php echo e(route('audit-logs.index')); ?>" method="GET" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">User</label>
                <select name="user_id" class="form-select">
                    <option value="">Semua User</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($u->id); ?>" <?php echo e(request('user_id') == $u->id ? 'selected' : ''); ?>>
                        <?php echo e($u->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Tanggal Mulai</label>
                <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Tanggal Akhir</label>
                <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100 me-2">
                    <i class="bi bi-filter me-1"></i> Filter
                </button>
                <a href="<?php echo e(route('audit-logs.index')); ?>" class="btn btn-secondary">
                    <i class="bi bi-x-lg"></i>
                </a>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Waktu</th>
                        <th>User</th>
                        <th>Aksi</th>
                        <th>Deskripsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="width: 15%">
                            <small><?php echo e($log->created_at->format('d/m/Y H:i')); ?></small>
                        </td>
                        <td style="width: 15%">
                            <span class="fw-bold"><?php echo e($log->user->name); ?></span>
                            <br>
                            <small class="text-muted"><?php echo e($log->user->role); ?></small>
                        </td>
                        <td style="width: 15%">
                            <span class="badge bg-secondary font-monospace"><?php echo e($log->action); ?></span>
                        </td>
                        <td>
                            <?php echo e($log->description); ?>

                            <?php if($log->entity_type && $log->entity_id): ?>
                            <div class="mt-1">
                                <small class="text-muted font-monospace">
                                    Entity: <?php echo e(class_basename($log->entity_type)); ?> #<?php echo e($log->entity_id); ?>

                                </small>
                            </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center py-5">
                            <i class="bi bi-journal-text fs-1 text-muted"></i>
                            <p class="text-muted mt-2 mb-0">Belum ada data log.</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($logs->hasPages()): ?>
    <div class="card-footer">
        <?php echo e($logs->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/audit-logs/index.blade.php ENDPATH**/ ?>