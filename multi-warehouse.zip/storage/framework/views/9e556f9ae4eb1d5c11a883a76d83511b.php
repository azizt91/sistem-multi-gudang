

<?php $__env->startSection('title', 'Detail Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1">Detail Transaksi</h4>
                <p class="text-muted mb-0"><?php echo e($transaction->transaction_number); ?></p>
            </div>
            <div>
                <a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-secondary me-2">
                    <i class="bi bi-arrow-left me-1"></i> Kembali
                </a>
                <a href="<?php echo e(route('transactions.receipt', $transaction)); ?>" class="btn btn-primary">
                    <i class="bi bi-file-earmark-text me-1"></i> Tanda Terima
                </a>
            </div>
        </div>

        <!-- Transaction Card -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>
                    <i class="bi <?php echo e($transaction->type === 'in' ? 'bi-box-arrow-in-down text-success' : 'bi-box-arrow-up text-danger'); ?> me-2"></i>
                    <?php echo e($transaction->type_label); ?>

                </span>
                <span class="badge <?php echo e($transaction->type_badge_class); ?>"><?php echo e($transaction->type_label); ?></span>
            </div>
            <div class="card-body">
                <div class="row g-4">
                    <div class="col-md-6">
                        <h6 class="text-muted mb-3">Informasi Transaksi</h6>
                        <table class="table table-sm table-borderless mb-0">
                            <tr>
                                <td width="130"><strong>No. Transaksi</strong></td>
                                <td><?php echo e($transaction->transaction_number); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Tanggal</strong></td>
                                <td><?php echo e($transaction->transaction_date->format('d F Y, H:i')); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Petugas</strong></td>
                                <td><?php echo e($transaction->user->name); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Catatan</strong></td>
                                <td><?php echo e($transaction->notes ?: '-'); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6 class="text-muted mb-3">Informasi Barang</h6>
                        <table class="table table-sm table-borderless mb-0">
                            <tr>
                                <td width="130"><strong>Kode</strong></td>
                                <td><code><?php echo e($transaction->item->code); ?></code></td>
                            </tr>
                            <tr>
                                <td><strong>Nama</strong></td>
                                <td><?php echo e($transaction->item->name); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Kategori</strong></td>
                                <td><?php echo e($transaction->item->category->name ?? '-'); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Satuan</strong></td>
                                <td><?php echo e($transaction->item->unit->name); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <hr>

                <!-- Stock Changes -->
                <div class="row text-center">
                    <div class="col-4">
                        <div class="p-3 rounded" style="background: var(--table-hover);">
                            <small class="text-muted d-block">Stok Sebelum</small>
                            <span class="fs-4 fw-bold"><?php echo e($transaction->stock_before); ?></span>
                            <small class="text-muted d-block"><?php echo e($transaction->item->unit->abbreviation); ?></small>
                        </div>
                    </div>
                    <div class="col-4 d-flex align-items-center justify-content-center">
                        <div class="text-center">
                            <?php if($transaction->type === 'in'): ?>
                            <span class="badge bg-success fs-5">+<?php echo e($transaction->quantity); ?></span>
                            <?php else: ?>
                            <span class="badge bg-danger fs-5">-<?php echo e($transaction->quantity); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="p-3 rounded" style="background: var(--table-hover);">
                            <small class="text-muted d-block">Stok Sesudah</small>
                            <span class="fs-4 fw-bold"><?php echo e($transaction->stock_after); ?></span>
                            <small class="text-muted d-block"><?php echo e($transaction->item->unit->abbreviation); ?></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Receipt Status -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-file-earmark-text me-2"></i>Status Tanda Terima
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="d-flex align-items-center mb-3">
                            <?php if($transaction->sender_signature): ?>
                            <i class="bi bi-check-circle-fill text-success fs-4 me-2"></i>
                            <?php else: ?>
                            <i class="bi bi-circle text-muted fs-4 me-2"></i>
                            <?php endif; ?>
                            <div>
                                <strong><?php echo e($transaction->type === 'in' ? 'Tanda Tangan Pengirim' : 'Tanda Tangan Penerima'); ?></strong>
                                <br>
                                <small class="text-muted"><?php echo e($transaction->sender_name ?: 'Belum diisi'); ?></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex align-items-center mb-3">
                            <?php if($transaction->receiver_signature): ?>
                            <i class="bi bi-check-circle-fill text-success fs-4 me-2"></i>
                            <?php else: ?>
                            <i class="bi bi-circle text-muted fs-4 me-2"></i>
                            <?php endif; ?>
                            <div>
                                <strong><?php echo e($transaction->type === 'in' ? 'Tanda Tangan Penerima (Gudang)' : 'Tanda Tangan Pengirim (Gudang)'); ?></strong>
                                <br>
                                <small class="text-muted"><?php echo e($transaction->receiver_name ?: 'Belum diisi'); ?></small>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if($transaction->isReceiptLocked()): ?>
                <div class="alert alert-info mb-0">
                    <i class="bi bi-lock me-2"></i>
                    Tanda terima sudah dikunci pada <?php echo e($transaction->updated_at->format('d/m/Y H:i')); ?>.
                </div>
                <?php else: ?>
                <a href="<?php echo e(route('transactions.receipt', $transaction)); ?>" class="btn btn-outline-primary">
                    <i class="bi bi-pen me-1"></i> Input Tanda Tangan
                </a>
                <?php endif; ?>

                <?php if($transaction->hasCompleteSignatures()): ?>
                <a href="<?php echo e(route('transactions.receipt.pdf', $transaction)); ?>" class="btn btn-danger ms-2" target="_blank">
                    <i class="bi bi-file-pdf me-1"></i> Download PDF
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/transactions/show.blade.php ENDPATH**/ ?>