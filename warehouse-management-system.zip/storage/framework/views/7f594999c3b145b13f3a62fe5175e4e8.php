<div class="table-responsive">
    <table class="table table-hover mb-0">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Email</th>
                <th>Role</th>
                <th>Gudang</th>
                <th>Dibuat</th>
                <th style="width: 150px;">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="fw-semibold">
                    <?php echo e($user->name); ?>

                    <?php if($user->id === auth()->id()): ?>
                    <span class="badge bg-info ms-1">Anda</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <?php
                        $badgeClass = match($user->role) {
                            'admin' => 'bg-danger',
                            'owner' => 'bg-warning text-dark',
                            'staff' => 'bg-primary',
                            default => 'bg-secondary'
                        };
                    ?>
                    <span class="badge <?php echo e($badgeClass); ?>"><?php echo e(\App\Models\User::getRoles()[$user->role] ?? $user->role); ?></span>
                </td>
                <td><?php echo e($user->warehouse->name ?? '-'); ?></td>
                <td><?php echo e($user->created_at->format('d/m/Y')); ?></td>
                <td>
                    <div class="dropdown">
                        <button class="btn btn-sm btn-light border dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i class="bi bi-three-dots-vertical"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('users.edit', $user)); ?>">
                                    <i class="bi bi-pencil text-primary me-2"></i> Edit
                                </a>
                            </li>
                            <?php if($user->id !== auth()->id()): ?>
                            <li>
                                <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus user ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="dropdown-item text-danger">
                                        <i class="bi bi-trash me-2"></i> Hapus
                                    </button>
                                </form>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center py-5">
                    <i class="bi bi-inbox fs-1 text-muted"></i>
                    <p class="text-muted mt-2 mb-0">Belum ada user</p>
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php if($users->hasPages()): ?>
<div class="card-footer">
    <?php echo e($users->withQueryString()->links()); ?>

</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/users/partials/table.blade.php ENDPATH**/ ?>