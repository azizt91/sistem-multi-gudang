

<?php $__env->startSection('title', 'Detail Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-4">
        <!-- Item Info Card -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Informasi Barang</span>
                <?php if(auth()->user()->isAdmin()): ?>
                <a href="<?php echo e(route('items.edit', $item)); ?>" class="btn btn-sm btn-primary">
                    <i class="bi bi-pencil"></i> Edit
                </a>
                <?php endif; ?>
            </div>
            <div class="card-body text-center">
                <!-- Barcode -->
                <div class="mb-3 p-3 bg-white border rounded">
                    <img src="<?php echo e($item->generateBarcode()); ?>" alt="Barcode" class="img-fluid mb-2">
                    <p class="mb-0 fw-bold"><?php echo e($item->code); ?></p>
                </div>

                <h5 class="fw-bold"><?php echo e($item->name); ?></h5>
                
                <div class="d-flex justify-content-center gap-2 mb-3">
                    <span class="badge bg-secondary"><?php echo e($item->category->name); ?></span>
                    <?php if($item->isLowStock()): ?>
                    <span class="badge bg-danger">Stok Menipis</span>
                    <?php endif; ?>
                </div>

                <div class="row text-start">
                    <div class="col-6 mb-3">
                        <small class="text-muted d-block">Stok Saat Ini <?php if(isset($contextWarehouse)): ?> <small>(<?php echo e($contextWarehouse->name); ?>)</small> <?php endif; ?></small>
                        <span class="fw-bold fs-4 <?php echo e($item->isLowStock() ? 'text-danger' : 'text-success'); ?>">
                            <?php echo e($currentStock); ?>

                        </span>
                        <span class="text-muted"><?php echo e($item->unit->abbreviation); ?></span>
                    </div>
                    <div class="col-6 mb-3">
                        <small class="text-muted d-block">Minimum Stok</small>
                        <span class="fw-bold fs-4"><?php echo e($item->minimum_stock); ?></span>
                        <span class="text-muted"><?php echo e($item->unit->abbreviation); ?></span>
                    </div>
                    <div class="col-6 mb-3">
                        <small class="text-muted d-block">Satuan</small>
                        <span class="fw-semibold"><?php echo e($item->unit->name); ?></span>
                    </div>
                    <div class="col-6 mb-3">
                        <small class="text-muted d-block">Lokasi Rak</small>
                        <span class="fw-semibold"><?php echo e($item->rack_location ?? '-'); ?></span>
                    </div>
                </div>

                <hr>

                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('items.barcode', $item)); ?>" class="btn btn-outline-primary" target="_blank">
                        <i class="bi bi-printer me-1"></i> Cetak Barcode
                    </a>
                    <?php if(auth()->user()->canCreateTransaction()): ?>
                    <a href="<?php echo e(route('stock-headers.create-in')); ?>?item_id=<?php echo e($item->id); ?>" class="btn btn-success">
                        <i class="bi bi-plus-circle me-1"></i> Stok Masuk
                    </a>
                    <a href="<?php echo e(route('stock-headers.create-out')); ?>?item_id=<?php echo e($item->id); ?>" class="btn btn-danger">
                        <i class="bi bi-dash-circle me-1"></i> Stok Keluar
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>


        <!-- Stock Per Warehouse -->

        </div>


    <div class="col-lg-8">
        <!-- Stock Per Warehouse -->
        <?php if(auth()->user()->isAdmin() || auth()->user()->isOwner()): ?>
        <div class="card mb-4">
            <div class="card-header">
                <i class="bi bi-building me-2"></i>Stok per Gudang
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-sm table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Gudang</th>
                                <th class="text-end">Stok</th>
                                <th class="text-end">Min</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $item->warehouseItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($wi->warehouse->name); ?></td>
                                <td class="text-end fw-bold <?php echo e($wi->stock <= $wi->minimum_stock ? 'text-danger' : 'text-success'); ?>">
                                    <?php echo e($wi->stock); ?>

                                </td>
                                <td class="text-end text-muted"><?php echo e($wi->minimum_stock); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="text-center text-muted small py-2">Belum ada stok di gudang manapun</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Transaction History -->
        <div class="card">
            <div class="card-header">
                <i class="bi bi-clock-history me-2"></i>Riwayat Transaksi
            </div>
            <div class="card-body p-0">
                <?php if($item->stockTransactions->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Jenis</th>
                                <th class="text-end">Qty</th>
                                <th>Stok Sebelum</th>
                                <th>Stok Sesudah</th>
                                <th>User</th>
                                <th>Catatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $item->stockTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($transaction->transaction_date->format('d/m/Y H:i')); ?></td>
                                <td>
                                    <span class="badge <?php echo e($transaction->type_badge_class); ?>">
                                        <?php echo e($transaction->type_label); ?>

                                    </span>
                                </td>
                                <td class="text-end fw-semibold <?php echo e($transaction->type === 'in' ? 'text-success' : 'text-danger'); ?>">
                                    <?php echo e($transaction->type === 'in' ? '+' : '-'); ?><?php echo e($transaction->quantity); ?>

                                </td>
                                <td><?php echo e($transaction->stock_before); ?></td>
                                <td><?php echo e($transaction->stock_after); ?></td>
                                <td><?php echo e($transaction->user->name); ?></td>
                                <td><?php echo e($transaction->notes ?? '-'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-5 text-muted">
                    <i class="bi bi-inbox fs-1"></i>
                    <p class="mt-2 mb-0">Belum ada riwayat transaksi</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/items/show.blade.php ENDPATH**/ ?>