

<?php $__env->startSection('title', 'Tanda Terima - ' . $transaction->transaction_number); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="mb-1">Tanda Terima Transaksi</h4>
                <p class="text-muted mb-0"><?php echo e($transaction->transaction_number); ?></p>
            </div>
            <div>
                <a href="<?php echo e(route('transactions.show', $transaction)); ?>" class="btn btn-secondary me-2">
                    <i class="bi bi-arrow-left me-1"></i> Kembali
                </a>
                <?php if($transaction->hasCompleteSignatures()): ?>
                <a href="<?php echo e(route('transactions.receipt.pdf', $transaction)); ?>" class="btn btn-danger" target="_blank">
                    <i class="bi bi-file-pdf me-1"></i> Download PDF
                </a>
                <?php endif; ?>
            </div>
        </div>

        <?php if($transaction->isReceiptLocked()): ?>
        <div class="alert alert-info">
            <i class="bi bi-lock me-2"></i>
            <strong>Tanda terima sudah dikunci.</strong> Tidak dapat mengubah tanda tangan.
        </div>
        <?php endif; ?>

        <!-- Receipt Preview -->
        <div class="card mb-4" id="receiptPreview">
            <div class="card-body p-4" style="background: white; color: #000;">
                <!-- Company Header -->
                <div class="text-center mb-4 pb-3 border-bottom">
                    <h4 class="fw-bold mb-1">TANDA TERIMA</h4>
                    <p class="mb-0"><?php echo e($transaction->type_label); ?></p>
                </div>

                <!-- Transaction Info -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <table class="table table-borderless table-sm" style="color: #000;">
                            <tr>
                                <td width="140"><strong>No. Transaksi</strong></td>
                                <td>: <?php echo e($transaction->transaction_number); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Tanggal</strong></td>
                                <td>: <?php echo e($transaction->transaction_date->format('d F Y, H:i')); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Jenis</strong></td>
                                <td>: <span class="badge <?php echo e($transaction->type_badge_class); ?>"><?php echo e($transaction->type_label); ?></span></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-borderless table-sm" style="color: #000;">
                            <tr>
                                <td width="120"><strong>Petugas</strong></td>
                                <td>: <?php echo e($transaction->user->name); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Catatan</strong></td>
                                <td>: <?php echo e($transaction->notes ?: '-'); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <!-- Item Details -->
                <div class="table-responsive mb-4">
                    <table class="table table-bordered" style="color: #000;">
                        <thead class="table-light">
                            <tr>
                                <th>Kode Barang</th>
                                <th>Nama Barang</th>
                                <th class="text-center">Jumlah</th>
                                <th>Satuan</th>
                                <th>Stok Sebelum</th>
                                <th>Stok Sesudah</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><code><?php echo e($transaction->item->code); ?></code></td>
                                <td><?php echo e($transaction->item->name); ?></td>
                                <td class="text-center fw-bold">
                                    <?php if($transaction->type === 'in'): ?>
                                    <span class="text-success">+<?php echo e($transaction->quantity); ?></span>
                                    <?php else: ?>
                                    <span class="text-danger">-<?php echo e($transaction->quantity); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($transaction->item->unit->abbreviation); ?></td>
                                <td><?php echo e($transaction->stock_before); ?></td>
                                <td><?php echo e($transaction->stock_after); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Signatures Section -->
                <div class="row mt-5">
                    <div class="col-6 text-center">
                        <p class="mb-2"><strong><?php echo e($transaction->type === 'in' ? 'Pengirim' : 'Penerima'); ?></strong></p>
                        <div class="border rounded p-2 mb-2" style="min-height: 120px; background: #f8f9fa;">
                            <?php if($transaction->sender_signature): ?>
                            <img src="<?php echo e($transaction->sender_signature_url); ?>" alt="Tanda Tangan Pengirim" style="max-height: 100px; max-width: 100%;">
                            <?php else: ?>
                            <span class="text-muted small">Belum ditandatangani</span>
                            <?php endif; ?>
                        </div>
                        <p class="mb-0 border-top pt-2"><?php echo e($transaction->sender_name ?: '.........................'); ?></p>
                    </div>
                    <div class="col-6 text-center">
                        <p class="mb-2"><strong><?php echo e($transaction->type === 'in' ? 'Penerima (Gudang)' : 'Pengirim (Gudang)'); ?></strong></p>
                        <div class="border rounded p-2 mb-2" style="min-height: 120px; background: #f8f9fa;">
                            <?php if($transaction->receiver_signature): ?>
                            <img src="<?php echo e($transaction->receiver_signature_url); ?>" alt="Tanda Tangan Penerima" style="max-height: 100px; max-width: 100%;">
                            <?php else: ?>
                            <span class="text-muted small">Belum ditandatangani</span>
                            <?php endif; ?>
                        </div>
                        <p class="mb-0 border-top pt-2"><?php echo e($transaction->receiver_name ?: '.........................'); ?></p>
                    </div>
                </div>

                <!-- Footer -->
                <div class="text-center mt-4 pt-3 border-top">
                    <small class="text-muted">Dicetak pada: <?php echo e(now()->format('d/m/Y H:i:s')); ?></small>
                </div>
            </div>
        </div>

        <!-- Signature Form -->
        <?php if(!$transaction->isReceiptLocked()): ?>
        <div class="card">
            <div class="card-header">
                <i class="bi bi-pen me-2"></i>Input Tanda Tangan
            </div>
            <div class="card-body">
                <form id="signatureForm">
                    <?php echo csrf_field(); ?>
                    <div class="row g-4">
                        <!-- Sender Signature -->
                        <div class="col-md-6">
                            <div class="card h-100" style="background: var(--table-hover);">
                                <div class="card-body">
                                    <h6 class="fw-semibold mb-3">
                                        <i class="bi bi-person me-1"></i>
                                        <?php echo e($transaction->type === 'in' ? 'Pengirim' : 'Penerima'); ?>

                                    </h6>
                                    <div class="mb-3">
                                        <label class="form-label">Nama Lengkap</label>
                                        <input type="text" class="form-control" name="sender_name" 
                                               value="<?php echo e($transaction->sender_name); ?>" 
                                               placeholder="Masukkan nama lengkap">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Tanda Tangan <small class="text-muted">(gambar di kotak)</small></label>
                                        <div class="border rounded" style="background: white;">
                                            <canvas id="senderSignature" style="width: 100%; height: 150px; cursor: crosshair;"></canvas>
                                        </div>
                                        <div class="mt-2">
                                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="senderPad.clear()">
                                                <i class="bi bi-eraser"></i> Hapus
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="senderPad.undo()">
                                                <i class="bi bi-arrow-counterclockwise"></i> Undo
                                            </button>
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label class="form-label">Atau Upload Gambar</label>
                                        <input type="file" class="form-control form-control-sm" id="senderUpload" accept="image/*">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Receiver Signature -->
                        <div class="col-md-6">
                            <div class="card h-100" style="background: var(--table-hover);">
                                <div class="card-body">
                                    <h6 class="fw-semibold mb-3">
                                        <i class="bi bi-person-check me-1"></i>
                                        <?php echo e($transaction->type === 'in' ? 'Penerima (Gudang)' : 'Pengirim (Gudang)'); ?>

                                    </h6>
                                    <div class="mb-3">
                                        <label class="form-label">Nama Lengkap</label>
                                        <input type="text" class="form-control" name="receiver_name" 
                                               value="<?php echo e($transaction->receiver_name); ?>" 
                                               placeholder="Masukkan nama lengkap">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Tanda Tangan <small class="text-muted">(gambar di kotak)</small></label>
                                        <div class="border rounded" style="background: white;">
                                            <canvas id="receiverSignature" style="width: 100%; height: 150px; cursor: crosshair;"></canvas>
                                        </div>
                                        <div class="mt-2">
                                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="receiverPad.clear()">
                                                <i class="bi bi-eraser"></i> Hapus
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="receiverPad.undo()">
                                                <i class="bi bi-arrow-counterclockwise"></i> Undo
                                            </button>
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label class="form-label">Atau Upload Gambar</label>
                                        <input type="file" class="form-control form-control-sm" id="receiverUpload" accept="image/*">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="d-flex justify-content-between align-items-center">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="lockReceipt" name="lock_receipt">
                            <label class="form-check-label" for="lockReceipt">
                                <strong>Kunci tanda terima</strong>
                                <small class="text-muted d-block">Setelah dikunci, tanda tangan tidak bisa diubah</small>
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary" id="saveBtn">
                            <i class="bi bi-check-lg me-1"></i> Simpan Tanda Tangan
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/signature-pad.js')); ?>"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize signature pads
    const senderCanvas = document.getElementById('senderSignature');
    const receiverCanvas = document.getElementById('receiverSignature');
    
    if (senderCanvas && receiverCanvas) {
        window.senderPad = new SignaturePad(senderCanvas);
        window.receiverPad = new SignaturePad(receiverCanvas);
    }

    // Handle file uploads
    const senderUpload = document.getElementById('senderUpload');
    const receiverUpload = document.getElementById('receiverUpload');

    if (senderUpload) {
        senderUpload.addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                senderPad.uploadedFile = e.target.files[0];
            }
        });
    }

    if (receiverUpload) {
        receiverUpload.addEventListener('change', function(e) {
            if (e.target.files && e.target.files[0]) {
                receiverPad.uploadedFile = e.target.files[0];
            }
        });
    }

    // Handle form submission
    const form = document.getElementById('signatureForm');
    if (form) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const saveBtn = document.getElementById('saveBtn');
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<i class="bi bi-hourglass-split me-1"></i> Menyimpan...';

            const formData = new FormData(form);
            
            // Add signature images
            if (senderPad && !senderPad.isEmpty()) {
                const senderBlob = await new Promise(resolve => senderPad.toBlob(resolve));
                formData.append('sender_signature', senderBlob, 'sender.png');
            } else if (senderPad && senderPad.uploadedFile) {
                formData.append('sender_signature', senderPad.uploadedFile);
            }

            if (receiverPad && !receiverPad.isEmpty()) {
                const receiverBlob = await new Promise(resolve => receiverPad.toBlob(resolve));
                formData.append('receiver_signature', receiverBlob, 'receiver.png');
            } else if (receiverPad && receiverPad.uploadedFile) {
                formData.append('receiver_signature', receiverPad.uploadedFile);
            }

            try {
                const response = await fetch('<?php echo e(route("transactions.signatures.save", $transaction)); ?>', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: formData
                });

                const result = await response.json();

                if (result.success) {
                    alert('Tanda tangan berhasil disimpan!');
                    window.location.reload();
                } else {
                    alert(result.message || 'Gagal menyimpan tanda tangan');
                }
            } catch (error) {
                console.error(error);
                alert('Terjadi kesalahan saat menyimpan');
            } finally {
                saveBtn.disabled = false;
                saveBtn.innerHTML = '<i class="bi bi-check-lg me-1"></i> Simpan Tanda Tangan';
            }
        });
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\warehouse-management-system\resources\views/transactions/receipt.blade.php ENDPATH**/ ?>